define("JBrowse/Plugin", ['dojo/_base/declare'],
       function( declare ) {
return declare( null,
{
    constructor: function( args ) {
        this.browser = args.browser;
    }
});
});