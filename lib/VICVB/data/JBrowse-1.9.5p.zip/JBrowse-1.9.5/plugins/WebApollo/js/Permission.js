define([],
       function() {

return {
    NONE: 0x0,
    READ: 0x1,
    WRITE: 0x2
};

});