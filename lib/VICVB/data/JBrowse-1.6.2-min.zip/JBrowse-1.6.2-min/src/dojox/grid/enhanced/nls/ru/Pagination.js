define(
"dojox/grid/enhanced/nls/ru/Pagination", ({
	"descTemplate": "${2} - ${3} из ${1} ${0}",
	"firstTip": "Первая страница",
	"lastTip": "Последняя страница",
	"nextTip": "Следующая страница",
	"prevTip": "Предыдущая страница",
	"itemTitle": "элементов",
	"singularItemTitle": "элемент",
	"pageStepLabelTemplate": "Страница ${0}",
	"pageSizeLabelTemplate": "${0} элементов на странице",
	"allItemsLabelTemplate": "Все элементы",
	"gotoButtonTitle": "Перейти на указанную страницу",
	"dialogTitle": "Перейти на страницу",
	"dialogIndication": "Укажите номер страницы",
	"pageCountIndication": " (${0} страниц)",
	"dialogConfirm": "Перейти",
	"dialogCancel": "Отмена",
	"all": "Все"
})
);
