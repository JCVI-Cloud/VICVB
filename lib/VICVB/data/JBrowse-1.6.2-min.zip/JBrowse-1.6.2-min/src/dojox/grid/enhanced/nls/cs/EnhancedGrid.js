define(
"dojox/grid/enhanced/nls/cs/EnhancedGrid", ({
	singleSort: "Jednoduché řazení",
	nestedSort: "Vnořené řazení",
	ascending: "Po klepnutí bude řazeno vzestupně",
	descending: "Po klepnutí bude řazeno sestupně",
	sortingState: "${0} - ${1}",
	unsorted: "Tento sloupec neřadit",
	indirectSelectionRadio: "Řádek ${0}, jednotlivý výběr, přepínač",
	indirectSelectionCheckBox: "Řádek ${0}, vícenásobný výběr, zaškrtávací políčko",
	selectAll: "Vybrat vše"
})
);
