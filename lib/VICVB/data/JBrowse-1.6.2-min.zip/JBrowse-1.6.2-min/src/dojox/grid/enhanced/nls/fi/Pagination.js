define(
"dojox/grid/enhanced/nls/fi/Pagination", ({
	"descTemplate": "${2} - ${3} / ${1} ${0}",
	"firstTip": "Ensimmäinen sivu",
	"lastTip": "Viimeinen sivu",
	"nextTip": "Seuraava sivu",
	"prevTip": "Edellinen sivu",
	"itemTitle": "kohteet",
	"singularItemTitle": "kohde",
	"pageStepLabelTemplate": "Sivu ${0}",
	"pageSizeLabelTemplate": "${0} kohdetta sivulla",
	"allItemsLabelTemplate": "Kaikki kohteet",
	"gotoButtonTitle": "Siirry tietylle sivulle",
	"dialogTitle": "Siirry sivulle",
	"dialogIndication": "Määritä sivunumero",
	"pageCountIndication": " (${0} sivua)",
	"dialogConfirm": "Siirry",
	"dialogCancel": "Peruuta",
	"all": "Kaikki"
})
);
