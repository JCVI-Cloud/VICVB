define(
"dojox/grid/enhanced/nls/ru/EnhancedGrid", ({
	singleSort: "Однократная сортировка",
	nestedSort: "Вложенная сортировка",
	ascending: "Сортировка по возрастанию",
	descending: "Сортировка по убыванию",
	sortingState: "${0} - ${1}",
	unsorted: "Не сортировать этот столбец",
	indirectSelectionRadio: "Строка ${0}, единственный выбор, радиокнопка",
	indirectSelectionCheckBox: "Строка ${0}, множественный выбор, флажок",
	selectAll: "Выбрать все"
})
);
