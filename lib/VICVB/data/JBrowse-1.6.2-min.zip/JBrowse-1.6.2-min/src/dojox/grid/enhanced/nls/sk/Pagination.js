define(
"dojox/grid/enhanced/nls/sk/Pagination", ({
	"descTemplate": "${2} - ${3} z ${1} ${0}",
	"firstTip": "Prvá strana",
	"lastTip": "Posledná strana",
	"nextTip": "Ďalšia strana",
	"prevTip": "Predošlá strana",
	"itemTitle": "položky",
	"singularItemTitle": "položka",
	"pageStepLabelTemplate": "Strana ${0}",
	"pageSizeLabelTemplate": "${0} položiek na strane",
	"allItemsLabelTemplate": "Všetky položky",
	"gotoButtonTitle": "Prejsť na špecifickú stranu",
	"dialogTitle": "Prejsť na stranu",
	"dialogIndication": "Zadajte číslo strany",
	"pageCountIndication": " (${0} strán)",
	"dialogConfirm": "Prejsť",
	"dialogCancel": "Zrušiť",
	"all": "Všetko"
})
);
