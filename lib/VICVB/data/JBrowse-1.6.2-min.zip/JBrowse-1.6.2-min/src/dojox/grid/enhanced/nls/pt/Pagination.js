define(
"dojox/grid/enhanced/nls/pt/Pagination", ({
	"descTemplate": "${2} - ${3} de ${1} ${0}",
	"firstTip": "Primeira Página",
	"lastTip": "Última Página",
	"nextTip": "Próxima página",
	"prevTip": "Página anterior",
	"itemTitle": "itens",
	"singularItemTitle": "item",
	"pageStepLabelTemplate": "Página ${0}",
	"pageSizeLabelTemplate": "${0} itens por página",
	"allItemsLabelTemplate": "Todos os itens",
	"gotoButtonTitle": "Acesse uma página específica",
	"dialogTitle": "Acesse a Página",
	"dialogIndication": "Especifique o número da página",
	"pageCountIndication": " (${0} páginas)",
	"dialogConfirm": "Ir",
	"dialogCancel": "Cancelar",
	"all": "Todos"
})
);
