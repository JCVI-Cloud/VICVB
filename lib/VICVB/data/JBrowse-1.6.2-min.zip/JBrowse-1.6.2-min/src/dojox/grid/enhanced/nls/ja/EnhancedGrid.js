define(
"dojox/grid/enhanced/nls/ja/EnhancedGrid", ({
	singleSort: "単一ソート",
	nestedSort: "入れ子ソート",
	ascending: "クリックすると昇順でソート",
	descending: "クリックすると降順でソート",
	sortingState: "${0} - ${1}",
	unsorted: "この列をソートしない",
	indirectSelectionRadio: "行 ${0}、単一選択、ラジオ・ボックス",
	indirectSelectionCheckBox: "行 ${0}、複数選択、チェック・ボックス",
	selectAll: "すべて選択"
})
);
