define(
"dojox/grid/enhanced/nls/zh-tw/Pagination", ({
	"descTemplate": "${2} - ${3} / ${1} ${0}",
	"firstTip": "首頁",
	"lastTip": "末頁",
	"nextTip": "下一頁",
	"prevTip": "上一頁",
	"itemTitle": "項目",
	"singularItemTitle": "項目",
	"pageStepLabelTemplate": "頁面 ${0}",
	"pageSizeLabelTemplate": "每頁 ${0} 個項目",
	"allItemsLabelTemplate": "所有項目",
	"gotoButtonTitle": "跳至特定的頁面",
	"dialogTitle": "跳至頁面",
	"dialogIndication": "指定頁碼",
	"pageCountIndication": " （${0} 個頁面）",
	"dialogConfirm": "執行",
	"dialogCancel": "取消",
	"all": "全部"
})
);
