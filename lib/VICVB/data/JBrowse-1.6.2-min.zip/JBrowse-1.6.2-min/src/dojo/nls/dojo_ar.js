define('dojo/nls/dojo_ar',{
'dijit/nls/loading':{"loadingState":"جاري التحميل...","errorState":"عفوا، حدث خطأ"}
,
'dijit/nls/common':{"buttonOk":"حسنا","buttonCancel":"الغاء","buttonSave":"حفظ","itemClose":"اغلاق"}
,
'dijit/form/nls/validate':{"invalidMessage":"القيمة التي تم ادخالها غير صحيحة.","missingMessage":"يجب ادخال هذه القيمة.","rangeMessage":"هذه القيمة ليس بالمدى الصحيح."}
,
'dijit/form/nls/ComboBox':{"previousMessage":"الاختيارات السابقة","nextMessage":"مزيد من الاختيارات"}
});