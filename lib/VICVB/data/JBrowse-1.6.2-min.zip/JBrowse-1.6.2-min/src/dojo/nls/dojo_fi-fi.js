define('dojo/nls/dojo_fi-fi',{
'dijit/nls/loading':{"loadingState":"Lataus on meneillään...","errorState":"On ilmennyt virhe."}
,
'dijit/nls/common':{"buttonOk":"OK","buttonCancel":"Peruuta","buttonSave":"Tallenna","itemClose":"Sulje"}
,
'dijit/form/nls/validate':{"invalidMessage":"Annettu arvo ei kelpaa.","missingMessage":"Tämä arvo on pakollinen.","rangeMessage":"Tämä arvo on sallitun alueen ulkopuolella."}
,
'dijit/form/nls/ComboBox':{"previousMessage":"Edelliset valinnat","nextMessage":"Lisää valintoja"}
});