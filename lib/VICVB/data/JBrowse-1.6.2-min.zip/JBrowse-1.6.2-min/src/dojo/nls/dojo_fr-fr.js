define('dojo/nls/dojo_fr-fr',{
'dijit/nls/loading':{"loadingState":"Chargement...","errorState":"Une erreur est survenue"}
,
'dijit/nls/common':{"buttonOk":"OK","buttonCancel":"Annuler","buttonSave":"Sauvegarder","itemClose":"Fermer"}
,
'dijit/form/nls/validate':{"invalidMessage":"La valeur indiquée n'est pas correcte.","missingMessage":"Cette valeur est requise.","rangeMessage":"Cette valeur n'est pas comprise dans la plage autorisée."}
,
'dijit/form/nls/ComboBox':{"previousMessage":"Choix précédents","nextMessage":"Plus de choix"}
});