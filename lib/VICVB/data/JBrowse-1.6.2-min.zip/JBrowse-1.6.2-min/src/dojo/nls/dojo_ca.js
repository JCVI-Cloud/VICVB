define('dojo/nls/dojo_ca',{
'dijit/nls/loading':{"loadingState":"S'està carregant...","errorState":"Ens sap greu. S'ha produït un error."}
,
'dijit/nls/common':{"buttonOk":"D'acord","buttonCancel":"Cancel·la","buttonSave":"Desa","itemClose":"Tanca"}
,
'dijit/form/nls/validate':{"invalidMessage":"El valor introduït no és vàlid","missingMessage":"Aquest valor és necessari","rangeMessage":"Aquest valor és fora de l'interval"}
,
'dijit/form/nls/ComboBox':{"previousMessage":"Opcions anteriors","nextMessage":"Més opcions"}
});