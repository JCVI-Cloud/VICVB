define('dojo/nls/dojo_tr',{
'dijit/nls/loading':{"loadingState":"Yükleniyor...","errorState":"Üzgünüz, bir hata oluştu"}
,
'dijit/nls/common':{"buttonOk":"Tamam","buttonCancel":"İptal","buttonSave":"Kaydet","itemClose":"Kapat"}
,
'dijit/form/nls/validate':{"invalidMessage":"Girilen değer geçersiz.","missingMessage":"Bu değer gerekli.","rangeMessage":"Bu değer aralık dışında."}
,
'dijit/form/nls/ComboBox':{"previousMessage":"Önceki seçenekler","nextMessage":"Diğer seçenekler"}
});