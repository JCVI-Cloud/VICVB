define('dojo/nls/dojo_ru',{
'dijit/nls/loading':{"loadingState":"Загрузка...","errorState":"Извините, возникла ошибка"}
,
'dijit/nls/common':{"buttonOk":"ОК","buttonCancel":"Отмена","buttonSave":"Сохранить","itemClose":"Закрыть"}
,
'dijit/form/nls/validate':{"invalidMessage":"Указано недопустимое значение.","missingMessage":"Это обязательное значение.","rangeMessage":"Это значение вне диапазона."}
,
'dijit/form/nls/ComboBox':{"previousMessage":"Предыдущие варианты","nextMessage":"Следующие варианты"}
});