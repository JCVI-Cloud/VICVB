define('dojo/nls/dojo_sl',{
'dijit/nls/loading':{"loadingState":"Nalaganje ...","errorState":"Oprostite, prišlo je do napake."}
,
'dijit/nls/common':{"buttonOk":"V redu","buttonCancel":"Prekliči","buttonSave":"Shrani","itemClose":"Zapri"}
,
'dijit/form/nls/validate':{"invalidMessage":"Vnesena vrednost ni veljavna.","missingMessage":"Ta vrednost je zahtevana.","rangeMessage":"Ta vrednost je izven območja."}
,
'dijit/form/nls/ComboBox':{"previousMessage":"Prejšnje izbire","nextMessage":"Dodatne izbire"}
});