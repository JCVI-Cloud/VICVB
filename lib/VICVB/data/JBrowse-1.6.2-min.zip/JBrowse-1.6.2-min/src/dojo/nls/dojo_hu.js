define('dojo/nls/dojo_hu',{
'dijit/nls/loading':{"loadingState":"Betöltés...","errorState":"Sajnálom, hiba történt"}
,
'dijit/nls/common':{"buttonOk":"OK","buttonCancel":"Mégse","buttonSave":"Mentés","itemClose":"Bezárás"}
,
'dijit/form/nls/validate':{"invalidMessage":"A megadott érték érvénytelen.","missingMessage":"Meg kell adni egy értéket.","rangeMessage":"Az érték kívül van a megengedett tartományon."}
,
'dijit/form/nls/ComboBox':{"previousMessage":"Előző menüpontok","nextMessage":"További menüpontok"}
});