define('dojo/nls/dojo_sk',{
'dijit/nls/loading':{"loadingState":"Zavádzanie...","errorState":"Nastala chyba"}
,
'dijit/nls/common':{"buttonOk":"OK","buttonCancel":"Zrušiť","buttonSave":"Uložiť","itemClose":"Zatvoriť"}
,
'dijit/form/nls/validate':{"invalidMessage":"Zadaná hodnota nie je platná.","missingMessage":"Táto hodnota je vyžadovaná.","rangeMessage":"Táto hodnota je mimo rozsah."}
,
'dijit/form/nls/ComboBox':{"previousMessage":"Predchádzajúce voľby","nextMessage":"Ďalšie voľby"}
});