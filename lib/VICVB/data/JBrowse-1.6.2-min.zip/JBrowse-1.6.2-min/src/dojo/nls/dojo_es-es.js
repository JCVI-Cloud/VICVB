define('dojo/nls/dojo_es-es',{
'dijit/nls/loading':{"loadingState":"Cargando...","errorState":"Lo siento, se ha producido un error"}
,
'dijit/nls/common':{"buttonOk":"Aceptar","buttonCancel":"Cancelar","buttonSave":"Guardar","itemClose":"Cerrar"}
,
'dijit/form/nls/validate':{"invalidMessage":"El valor especificado no es válido.","missingMessage":"Este valor es necesario.","rangeMessage":"Este valor está fuera del intervalo."}
,
'dijit/form/nls/ComboBox':{"previousMessage":"Opciones anteriores","nextMessage":"Más opciones"}
});