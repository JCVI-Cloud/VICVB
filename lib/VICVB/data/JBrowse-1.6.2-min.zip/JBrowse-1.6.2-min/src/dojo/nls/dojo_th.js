define('dojo/nls/dojo_th',{
'dijit/nls/loading':{"loadingState":"กำลังโหลด...","errorState":"ขออภัย เกิดข้อผิดพลาด"}
,
'dijit/nls/common':{"buttonOk":"ตกลง","buttonCancel":"ยกเลิก","buttonSave":"บันทึก","itemClose":"ปิด"}
,
'dijit/form/nls/validate':{"invalidMessage":"ค่าที่ป้อนไม่ถูกต้อง","missingMessage":"จำเป็นต้องมีค่านี้","rangeMessage":"ค่านี้เกินช่วง"}
,
'dijit/form/nls/ComboBox':{"previousMessage":"การเลือกก่อนหน้า","nextMessage":"การเลือกเพิ่มเติม"}
});