define('dojo/nls/dojo_pt-pt',{
'dijit/nls/loading':{"loadingState":"A carregar...","errorState":"Lamentamos, mas ocorreu um erro"}
,
'dijit/nls/common':{"buttonOk":"OK","buttonCancel":"Cancelar","buttonSave":"Guardar","itemClose":"Fechar"}
,
'dijit/form/nls/validate':{"invalidMessage":"O valor introduzido não é válido.","missingMessage":"Este valor é requerido.","rangeMessage":"Este valor encontra-se fora do intervalo."}
,
'dijit/form/nls/ComboBox':{"previousMessage":"Opções anteriores","nextMessage":"Mais opções"}
});