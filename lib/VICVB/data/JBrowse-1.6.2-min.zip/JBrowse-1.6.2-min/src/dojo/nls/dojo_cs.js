define('dojo/nls/dojo_cs',{
'dijit/nls/loading':{"loadingState":"Probíhá načítání...","errorState":"Omlouváme se, došlo k chybě"}
,
'dijit/nls/common':{"buttonOk":"OK","buttonCancel":"Storno","buttonSave":"Uložit","itemClose":"Zavřít"}
,
'dijit/form/nls/validate':{"invalidMessage":"Zadaná hodnota není platná.","missingMessage":"Tato hodnota je vyžadována.","rangeMessage":"Tato hodnota je mimo rozsah."}
,
'dijit/form/nls/ComboBox':{"previousMessage":"Předchozí volby","nextMessage":"Další volby"}
});