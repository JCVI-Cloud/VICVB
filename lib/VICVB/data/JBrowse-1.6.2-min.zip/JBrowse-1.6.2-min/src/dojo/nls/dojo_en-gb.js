define('dojo/nls/dojo_en-gb',{
'dijit/nls/loading':{"loadingState":"Loading...","errorState":"Sorry, an error occurred"}
,
'dijit/nls/common':{"buttonOk":"OK","buttonCancel":"Cancel","buttonSave":"Save","itemClose":"Close"}
,
'dijit/form/nls/validate':{"invalidMessage":"The value entered is not valid.","missingMessage":"This value is required.","rangeMessage":"This value is out of range."}
,
'dijit/form/nls/ComboBox':{"previousMessage":"Previous choices","nextMessage":"More choices"}
});