define('dojo/nls/dojo_it-it',{
'dijit/nls/loading':{"loadingState":"Caricamento in corso...","errorState":"Si è verificato un errore"}
,
'dijit/nls/common':{"buttonOk":"OK","buttonCancel":"Annulla","buttonSave":"Salva","itemClose":"Chiudi"}
,
'dijit/form/nls/validate':{"invalidMessage":"Il valore immesso non è valido.","missingMessage":"Questo valore è obbligatorio.","rangeMessage":"Questo valore non è compreso nell'intervallo."}
,
'dijit/form/nls/ComboBox':{"previousMessage":"Scelte precedenti","nextMessage":"Altre scelte"}
});