define('dojo/nls/dojo_de-de',{
'dijit/nls/loading':{"loadingState":"Wird geladen...","errorState":"Es ist ein Fehler aufgetreten."}
,
'dijit/nls/common':{"buttonOk":"OK","buttonCancel":"Abbrechen","buttonSave":"Speichern","itemClose":"Schließen"}
,
'dijit/form/nls/validate':{"invalidMessage":"Der eingegebene Wert ist ungültig. ","missingMessage":"Dieser Wert ist erforderlich.","rangeMessage":"Dieser Wert liegt außerhalb des gültigen Bereichs. "}
,
'dijit/form/nls/ComboBox':{"previousMessage":"Vorherige Auswahl","nextMessage":"Weitere Auswahlmöglichkeiten"}
});